import face_recognition



image = face_recognition_models.cnn_face_detector_model_location()
face_locations = face_recognition_models.face_recognition_model_location(image)



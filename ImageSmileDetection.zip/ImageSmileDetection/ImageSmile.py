import cv2 as cv
import winsound
from _datetime import datetime
from imutils.video import VideoStream
from pyzbar import pyzbar
import imutils
import time
from MysqlConnection import insertdata

print("in Face and smile")
face_classifier = cv.CascadeClassifier('C:/Users/suraj_kumar/PycharmProjects/Demo/Cascade_files/cascade.xml')
smile_classifier = cv.CascadeClassifier('C:/Users/suraj_kumar/PycharmProjects/Demo/Cascade_files/Haar_smile.xml')
img = cv.imread('C:/Users/suraj_kumar/Pictures/smile.jpg')
sm_ratio = 0
img = imutils.resize(img, 900)
gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
# gray_img = cv.GaussianBlur(gray, (21, 21), 0)
faces = face_classifier.detectMultiScale(gray, 1.3, 5)
smile = smile_classifier.detectMultiScale(gray, scaleFactor=1.3,
                                          minNeighbors=22,
                                          minSize=(25, 25))
# print("Found {0} faces!".format(len(faces)))
for (x, y, w, h) in faces:
    cv.rectangle(gray, (x, y), (x + w, y + h), (255, 0, 0), 1)
    roi_gray = gray[y:y + h, x:x + w]
    roi_img = img[y:y + h, x:x + w]
    # print("Found {0} faces!".format(len(faces)))
    for (sx, sy, sw, sh) in smile:
        cv.rectangle(img, (sx, sy), (sx + sw, sy + sh), (0, 255, 0), 1)
        sm_ratio = str(round(sw / sx, 2))
        font = cv.FONT_HERSHEY_SIMPLEX
        cv.putText(img, 'Smile Scale : ' + sm_ratio, (10, 50), font, 1, (200, 255, 155), 2, cv.LINE_AA)
        smile_ratios = sm_ratio

        # cv.imwrite('C:/Users/suraj_kumar/Pictures/Saved Pictures/smile.jpg', img)
        print(smile_ratios)

cv.imshow('demo', img)
# print("Found {0} faces!".format(len(faces)))
cv.waitKey(0)

# img = imutils.resize(img, 700)



    #print(sm_ratio)





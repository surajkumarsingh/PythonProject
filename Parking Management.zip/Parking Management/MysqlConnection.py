import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode


def insertdata(name, eid, v_type, v_number, times):
    print("Inserting Data")
    try:
        connection = mysql.connector.connect(host='localhost', database='Parking_management',  user='root', password='root')
        cursor = connection.cursor(prepared=True)

        sql_query = """ INSERT INTO `Parking`
                          (`Name`, `Id`,`vehicle_Type`, `Vehicle_Number`, `entry_date`) VALUES (%s,%s,%s,%s,%s)"""

        # Convert data into tuple format
        insert_tuple = (name, eid, v_type, v_number, times)
        result = cursor.execute(sql_query, insert_tuple)
        connection.commit()
        print("inserted successfully in table", result)
    except mysql.connector.Error as error:
        connection.rollback()
        print("Failed inserting data into MySQL table {}".format(error))
    finally:
        # closing database connection.
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")
